#!/bin/bash
for i in HPE-GPG-Public-Keys/*
do
echo "$i"
sleep 0.2
rpm --import "$i"
done

